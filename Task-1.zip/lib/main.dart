import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
      home: Scaffold(
          backgroundColor: Colors.pink,
          body: Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Icon(
                Icons.settings,
                size: 30,
                color: Colors.white,
              ),
              const Icon(
                Icons.notification_add,
                size: 30,
                color: Colors.white,
              ),
            ]),
            Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Image.network(
                'https://www.nicepng.com/png/full/182-1829287_cammy-lin-ux-designer-circle-picture-profile-girl.png',
                width: 130,
                height: 130,
              ),
              const Text('Jonny Lulu', style: TextStyle(color: Colors.white, fontSize: 25)),
              const Text('China', style: TextStyle(color: Colors.white, fontSize: 22)),
            ]),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(width: 21),
                const Text('233', style: TextStyle(color: Colors.white, fontSize: 20)),
                const Text('349', style: TextStyle(color: Colors.white, fontSize: 20)),
                SizedBox(width: 25),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(width: 25),
                const Text('Follows', style: TextStyle(color: Colors.white, fontSize: 20)),
                const Text('Following', style: TextStyle(color: Colors.white, fontSize: 20)),
                SizedBox(width: 25),
              ],
            ),
            Container(
                color: Colors.white,
                height: 363,
                width: 360,
                child: Row(children: [
                  Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                      const Icon(
                        Icons.collections,
                        size: 30,
                        color: Colors.grey,
                      ),
                      const Text('Shots', style: TextStyle(color: Colors.grey, fontSize: 20)),
                      SizedBox(width: 200),
                      const Text('35', style: TextStyle(color: Colors.grey, fontSize: 20)),
                      const Icon(
                        Icons.arrow_right,
                        size: 30,
                        color: Colors.grey,
                      ),
                    ]),
                    Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                      const Icon(
                        Icons.heart_broken,
                        size: 30,
                        color: Colors.grey,
                      ),
                      const Text('Likes', style: TextStyle(color: Colors.grey, fontSize: 20)),
                      SizedBox(width: 200),
                      const Text('236', style: TextStyle(color: Colors.grey, fontSize: 20)),
                      const Icon(
                        Icons.arrow_right,
                        size: 30,
                        color: Colors.grey,
                      ),
                    ]),
                    Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                      const Icon(
                        Icons.inbox,
                        size: 30,
                        color: Colors.grey,
                      ),
                      const Text('Buckets', style: TextStyle(color: Colors.grey, fontSize: 20)),
                      SizedBox(width: 190),
                      const Text('26', style: TextStyle(color: Colors.grey, fontSize: 20)),
                      const Icon(
                        Icons.arrow_right,
                        size: 30,
                        color: Colors.grey,
                      ),
                    ]),
                    Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                      const Icon(
                        Icons.tag,
                        size: 30,
                        color: Colors.grey,
                      ),
                      const Text('Tags', style: TextStyle(color: Colors.grey, fontSize: 20)),
                      SizedBox(width: 200),
                      const Text('100', style: TextStyle(color: Colors.grey, fontSize: 20)),
                      const Icon(
                        Icons.arrow_right,
                        size: 30,
                        color: Colors.grey,
                      ),
                    ]),
                  ])
                ])),
          ]))));
}

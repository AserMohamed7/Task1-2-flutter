import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
      home: Scaffold(
          backgroundColor: Colors.purpleAccent[100],
          body: Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('9:41',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 20,
                  )),
              const Icon(
                Icons.battery_full,
                size: 30,
                color: Colors.black,
              ),
            ]),
            Row(children: [
              const Icon(
                Icons.settings,
                size: 30,
                color: Colors.black,
              ),
            ]),
            Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Image.network(
                'https://www.nicepng.com/png/full/182-1829287_cammy-lin-ux-designer-circle-picture-profile-girl.png',
                width: 100,
                height: 100,
              ),
              const Text('Mary Smith', style: TextStyle(color: Colors.black, fontSize: 25)),
              const Text('SMS : 415-555-1212', style: TextStyle(color: Colors.black, fontSize: 22)),
            ]),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [
                          Colors.purple,
                          Colors.grey,
                        ])),
                    width: 120,
                    height: 80,
                    margin: EdgeInsets.only(left: 60, top: 40),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      const Text('2', style: TextStyle(color: Colors.white, fontSize: 25)),
                      const Text('Unclaimed', style: TextStyle(color: Colors.white, fontSize: 25)),
                    ])),
                Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [
                          Colors.indigo,
                          Colors.purple
                        ])),
                    width: 120,
                    height: 80,
                    margin: EdgeInsets.only(right: 55, top: 40),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      const Text('2880', style: TextStyle(color: Colors.white, fontSize: 25)),
                      const Text('Monthly Earn', style: TextStyle(color: Colors.white, fontSize: 20)),
                    ]))
              ],
            ),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('Action Required', style: TextStyle(color: Colors.black, fontSize: 15)),
              CircleAvatar(
                backgroundColor: Colors.indigo,
                child: const Text('18', style: TextStyle(color: Colors.white, fontSize: 15)),
              )
            ]),
          ]))));
}
